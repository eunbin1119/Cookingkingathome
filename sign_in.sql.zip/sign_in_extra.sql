
--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `find`
--
ALTER TABLE `find`
  ADD PRIMARY KEY (`id`);

--
-- 테이블의 인덱스 `john`
--
ALTER TABLE `john`
  ADD PRIMARY KEY (`id`);
