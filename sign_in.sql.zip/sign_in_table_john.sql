
-- --------------------------------------------------------

--
-- 테이블 구조 `john`
--

CREATE TABLE `john` (
  `id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `age` int(50) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
