
-- --------------------------------------------------------

--
-- 테이블 구조 `find`
--

CREATE TABLE `find` (
  `id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `time` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
