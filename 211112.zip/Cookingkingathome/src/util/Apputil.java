package util;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class Apputil {
	public static void alert(String msg, String header) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("�˸�");
	    alert.setHeaderText(header);
	    alert.setContentText(msg);
	    
	    alert.show();
	}

}
